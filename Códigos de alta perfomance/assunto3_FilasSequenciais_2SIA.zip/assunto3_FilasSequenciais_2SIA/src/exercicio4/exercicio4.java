package exercicio4;

import java.util.Scanner;

import tiposFilas.TipoFilaInt;

public class exercicio4 {

	public static void main(String[] args) {
		Scanner le = new Scanner(System.in);
		TipoFilaInt filaProcessos = new TipoFilaInt();
		int pid , op;
		
		do {
			System.out.println("Digite \n\t1- Submeter processos \n\t2- Executar processo" + "\n\t3");
			op = le.nextInt();
			switch (op) {
			case 1:
				System.out.println("Informe pid do prcesso que foi submetido para"  + "execu��o: ");
				pid = le.nextInt();
				filaProcessos.enqueue(pid);
				break;
			case 2:
				if(filaProcessos.isEmpty()) {
				pid = filaProcessos.dequeue();
				System.out.println("Processo" + pid + "Est� sendo processado");
				System.out.println("Processo" + pid + "foi conclido? (1-sim/2-n�o)");
				int resp = le.nextInt();
				if ( resp == 2) {
					filaProcessos.enqueue(pid);
				}else {
					System.out.println("Processos" + pid + "foi concluido com sucesso!");
				}
			}	
				break;
			case 3 :
				if(filaProcessos.isEmpty())
					System.out.println("Shutdown...");
				else {
					System.out.println("h� processos na fila. Deseja encerrar todos?(1-sim/2-n�o)");
					int resp = le.nextInt();
					if(resp == 1) {
						while(filaProcessos.isEmpty())
							System.out.println("Encerrando precesso" + filaProcessos.dequeue());
					}
					else 
						op = 0;
				}
				break;
				default:
					System.out.println("Op��o inv�lida");
			}
		}while(op != 3);

	}

}
