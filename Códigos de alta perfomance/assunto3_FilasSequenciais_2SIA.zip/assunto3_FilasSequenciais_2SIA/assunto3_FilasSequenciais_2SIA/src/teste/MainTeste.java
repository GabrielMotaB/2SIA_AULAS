package teste;

import tiposFilas.TipoFilaInt;

public class MainTeste {

	public static void main(String[] args) {
		
		TipoFilaInt fila = new TipoFilaInt();
		fila.init();
		
		fila.enqueue(23);
		fila.enqueue(66);
		fila.enqueue(17);
		
		if (!fila.isEmpty())
			System.out.println(" Valor retirado da fila: " + fila.dequeue());
		else
			System.out.println("Fila Vazia!");
		
		fila.enqueue(8);
		System.out.println("Esvaziando a fila...");
		while(!fila.isEmpty())
			System.out.println(" Valor retirado da fila: " + fila.dequeue());

		if (!fila.isEmpty()) {
			int valor = fila.first();
			System.out.println(valor);
		}
		else
			System.out.println("Fila vazia!");
		
	}

}
